# # clip_preprocessed_dataset.py

# from torchvision import transforms
# from PIL import Image
# import torch
# import clip
# import torch.utils.data

# class ClipPreprocessedDataset(torch.utils.data.Dataset):
#     def __init__(self, dataset, clip_model_name="ViT-B/32"):
#         self.dataset = dataset
#         self.clip_model, self.clip_preprocess = clip.load(clip_model_name, device='cpu')

#     def __len__(self):
#         return len(self.dataset)

#     def __getitem__(self, idx):
#         img, label = self.dataset[idx]
#         if not isinstance(img, Image.Image):
#             img = transforms.ToPILImage()(img)
#         img = self.clip_preprocess(img)
#         return img, label


from PIL import Image
from torchvision import transforms
import torch.utils.data
import clip

class ClipPreprocessedDataset(torch.utils.data.Dataset):
    def __init__(self, dataset, clip_model_name="ViT-B/32", resize_size=(224, 224)):
        self.dataset = dataset
        self.resize_size = resize_size
        self.clip_model, self.clip_preprocess = clip.load(clip_model_name, device='cpu')

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, idx):
        print("Getting item:", idx)
        img, label = self.dataset[idx]
        if not isinstance(img, Image.Image):
            img = transforms.ToPILImage()(img)

        # Resize the image to the expected input size of the CLIP model
        resize_transform = transforms.Resize((224, 224))
        img = resize_transform(img)

        # Apply CLIP preprocessing
        img = self.clip_preprocess(img)

        # Print the post-CLIP preprocessing size
        print("Post-CLIP preprocessing size:", img.shape)

        return img, label

